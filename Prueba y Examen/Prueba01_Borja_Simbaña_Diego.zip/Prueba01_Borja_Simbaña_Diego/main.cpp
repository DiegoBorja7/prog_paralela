#include <mpi.h>
#include <fmt/core.h>
#include <complex>
#include <iostream>
#include <vector>
#include <cmath>
#include <cstring>
#include <SFML/Graphics.hpp>

#ifdef _WIN32
#include <windows.h>
#endif

#define ANCHO_PANTALLA 1600
#define ALTO_PANTALLA 900

double min_lim_x = -1.5, max_lim_x = 1.5;
double min_lim_y = -1.0, max_lim_y = 1.0;
int max_ciclos = 50;
int ejecucion_activa = 1;

const std::complex<double> root_a(1.0, 0.0);
const std::complex<double> root_b(-0.5, std::sqrt(3.0) / 2.0);
const std::complex<double> root_c(-0.5, -std::sqrt(3.0) / 2.0);
const double TOLERANCIA = 1e-4;

uint32_t rotar_bits(uint32_t dato) {
    return ((dato & 0x000000FF) << 24) | ((dato & 0x0000FF00) << 8) |
           ((dato & 0x00FF0000) >> 8) | ((dato & 0xFF000000) >> 24);
}

std::vector<uint32_t> mapa_crom = {
    rotar_bits(0xFF1010FF), rotar_bits(0xF31017FF), rotar_bits(0xE8101EFF), rotar_bits(0xDC1126FF),
    rotar_bits(0xD1112DFF), rotar_bits(0xC51235FF), rotar_bits(0xBA123CFF), rotar_bits(0xAE1343FF),
    rotar_bits(0xA3134BFF), rotar_bits(0x971452FF), rotar_bits(0x8C145AFF), rotar_bits(0x801461FF),
    rotar_bits(0x74ADD1FF), rotar_bits(0x5588BEFF), rotar_bits(0x3E60AAFF), rotar_bits(0x313695FF)
};

uint32_t ejecutar_kernel(double cx, double cy, long long &acum_ciclos) {
    std::complex<double> z_val(cx, cy);
    int k = 0;
    int objetivo = -1;

    while (k < max_ciclos && std::abs(z_val) <= 2.0) {
        if (std::abs(z_val - root_a) < TOLERANCIA) { objetivo = 0; break; }
        if (std::abs(z_val - root_b) < TOLERANCIA) { objetivo = 1; break; }
        if (std::abs(z_val - root_c) < TOLERANCIA) { objetivo = 2; break; }

        std::complex<double> z3 = z_val * z_val * z_val;
        std::complex<double> deriv = 3.0 * z_val * z_val;
        
        if (std::abs(deriv) == 0.0) break; 

        z_val = z_val - (z3 - 1.0) / deriv;
        k++;
    }

    acum_ciclos += k;

    if (objetivo != -1) {
        return mapa_crom[(objetivo * 5 + k) % 16];
    }
    return 0xFF000000; 
}

void distribuir_carga(uint32_t ancho, uint32_t alto, uint32_t fila_ini, uint32_t fila_fin, uint32_t *buff_render, long long &acum_ciclos) {
    double pasox = (max_lim_x - min_lim_x) / ancho;
    double pasoy = (max_lim_y - min_lim_y) / alto;

    for (int j = fila_ini; j < fila_fin; j++) {
        for (int i = 0; i < ancho; i++) {
            double coord_x = min_lim_x + i * pasox;
            double coord_y = max_lim_y - j * pasoy;
            buff_render[(j - fila_ini) * ancho + i] = ejecutar_kernel(coord_x, coord_y, acum_ciclos);
        }
    }
}

int main(int argc, char **argv) {
    MPI_Init(&argc, &argv);

    int num_nodos, mi_rango;
    MPI_Comm_size(MPI_COMM_WORLD, &num_nodos);
    MPI_Comm_rank(MPI_COMM_WORLD, &mi_rango);

    int salto = std::ceil((ALTO_PANTALLA * 1.0) / num_nodos);
    int f_ini = mi_rango * salto;
    int f_fin = f_ini + salto;
    int excedente = salto * num_nodos - ALTO_PANTALLA;

    if (f_fin > ALTO_PANTALLA) f_fin = ALTO_PANTALLA;

    uint32_t *buffer_nodos = new uint32_t[ANCHO_PANTALLA * salto];
    uint32_t *buffer_maestro = nullptr;

    sf::RenderWindow* pantalla = nullptr;
    sf::Texture* lienzo = nullptr;
    sf::Sprite* actor = nullptr;
    sf::Font letras;

    if (mi_rango == 0) {
        buffer_maestro = new uint32_t[ANCHO_PANTALLA * ALTO_PANTALLA];
        std::memset(buffer_maestro, 0, ANCHO_PANTALLA * ALTO_PANTALLA * sizeof(uint32_t));
        
        pantalla = new sf::RenderWindow(sf::VideoMode({ANCHO_PANTALLA, ALTO_PANTALLA}), "Newton Fractal");
        
        #ifdef _WIN32
        HWND hnd = pantalla->getNativeHandle();
        ShowWindow(hnd, SW_MAXIMIZE);
        #endif

        lienzo = new sf::Texture({ANCHO_PANTALLA, ALTO_PANTALLA});
        actor = new sf::Sprite(*lienzo);
        letras.openFromFile("arial.ttf"); 
    }

    sf::Clock rel;
    int cont_frames = 0, fps_final = 0;

    while (true) {
        double sync_data[6];

        if (mi_rango == 0) {
            while (const std::optional ev = pantalla->pollEvent()) {
                if (ev->is<sf::Event::Closed>()) {
                    ejecucion_activa = 0;
                    pantalla->close();
                } else if (ev->is<sf::Event::KeyReleased>()) {
                    auto tecla = ev->getIf<sf::Event::KeyReleased>();
                    if (tecla->scancode == sf::Keyboard::Scan::Up) max_ciclos += 10;
                    if (tecla->scancode == sf::Keyboard::Scan::Down) max_ciclos = std::max(10, max_ciclos - 10);
                }
            }

            sync_data[0] = max_ciclos;
            sync_data[1] = min_lim_x;
            sync_data[2] = max_lim_x;
            sync_data[3] = min_lim_y;
            sync_data[4] = max_lim_y;
            sync_data[5] = ejecucion_activa;
        }

        MPI_Bcast(sync_data, 6, MPI_DOUBLE, 0, MPI_COMM_WORLD);

        max_ciclos = (int)sync_data[0];
        min_lim_x = sync_data[1];
        max_lim_x = sync_data[2];
        min_lim_y = sync_data[3];
        max_lim_y = sync_data[4];
        ejecucion_activa = (int)sync_data[5];

        if (ejecucion_activa == 0) break;

        long long local_cont = 0;
        double t_inicio = MPI_Wtime();
        
        distribuir_carga(ANCHO_PANTALLA, ALTO_PANTALLA, f_ini, f_fin, buffer_nodos, local_cont);
        
        double t_fin = (MPI_Wtime() - t_inicio) * 1000.0; 

        long long total_ciclos_g = 0;
        double max_time_g = 0.0;

        MPI_Reduce(&local_cont, &total_ciclos_g, 1, MPI_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&t_fin, &max_time_g, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

        if (mi_rango == 0) {
            std::memcpy(buffer_maestro, buffer_nodos, ANCHO_PANTALLA * salto * sizeof(uint32_t));

            for (int i = 1; i < num_nodos; i++) {
                int ajuste_salto = salto;
                if (i == num_nodos - 1) ajuste_salto = salto - excedente;

                MPI_Recv(buffer_nodos, ANCHO_PANTALLA * salto, MPI_UNSIGNED, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                std::memcpy(buffer_maestro + i * salto * ANCHO_PANTALLA, buffer_nodos, ajuste_salto * ANCHO_PANTALLA * sizeof(uint32_t));
            }

            lienzo->update((const uint8_t*)buffer_maestro);

            cont_frames++;
            if (rel.getElapsedTime().asSeconds() >= 1.0f) {
                fps_final = cont_frames;
                cont_frames = 0;
                rel.restart();
            }

            sf::Text info_stat(letras, fmt::format("MODO: MPI\nIter: {}\nCalc: {:.2f} ms\nTotal: {}\nFPS: {}", 
                                       max_ciclos, max_time_g, total_ciclos_g, fps_final), 22);
            info_stat.setFillColor(sf::Color::Cyan);
            info_stat.setPosition({15.f, 20.f});

            sf::Text instruc(letras, "Flechas Arriba/Abajo para zoom/iter", 20);
            instruc.setFillColor(sf::Color::Magenta);
            instruc.setPosition({15.f, ALTO_PANTALLA - 45.f});

            pantalla->clear();
            pantalla->draw(*actor);
            pantalla->draw(info_stat);
            pantalla->draw(instruc);
            pantalla->display();
        } else {
            MPI_Send(buffer_nodos, ANCHO_PANTALLA * salto, MPI_UNSIGNED, 0, 0, MPI_COMM_WORLD);
        }
    }

    delete[] buffer_nodos;
    if (mi_rango == 0) {
        delete[] buffer_maestro;
        delete actor;
        delete lienzo;
        delete pantalla;
    }

    MPI_Finalize();
    return 0;
}