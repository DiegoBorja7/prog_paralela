#include <SFML/Graphics.hpp>
#include <omp.h>
#include <fmt/core.h>
#include <cstring>
#include <chrono>
#include "arial_ttf.h"

#define CHANNELS 4
#define M 3

#define WIDTH 1600
#define HEIGHT 900

// Declaracion de la funcion del kernel CUDA
extern "C" double kernel_blur(const unsigned char *src_image, unsigned char *dst_image, int width, int height);

// Implementacion OpenMP
double blur_openmp(const unsigned char *src, unsigned char *dst, int width, int height)
{
    int K[M][M];

    auto start_time = std::chrono::high_resolution_clock::now();

#pragma omp parallel
    {

#pragma omp for
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                int r = 0, g = 0, b = 0, a = 0;
                int sum = 0;

                for (int i = -1; i <= 1; ++i)
                {
                    for (int j = -1; j <= 1; ++j)
                    {
                        int cur_x = x + j;
                        int cur_y = y + i;

                        if (cur_x >= 0 && cur_x < width && cur_y >= 0 && cur_y < height)
                        {
                            int peso = K[i + 1][j + 1];
                            int indice = (cur_y * width + cur_x) * CHANNELS;

                            r += src[indice] * peso;
                            g += src[indice + 1] * peso;
                            b += src[indice + 2] * peso;
                            a += src[indice + 3] * peso;
                            sum += peso;
                        }
                    }
                }

                // promedio de los canales
                int pixel_idx = (y * width + x) * CHANNELS;
                dst[pixel_idx] = r / sum;
                dst[pixel_idx + 1] = g / sum;
                dst[pixel_idx + 2] = b / sum;
                dst[pixel_idx + 3] = a / sum;
            }
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> ms = end_time - start_time;
    return ms.count();
}

int main()
{
    // cargar imagen
    sf::Image img;
    std::string filename = "imagen.jpg";

    if (!img.loadFromFile(filename))
    {
        fmt::println("Error al cargar la imagen: {}", filename);
        return 1;
    }

    int w = img.getSize().x;
    int h = img.getSize().y;
    size_t buffer_size = w * h * CHANNELS;

    const uint8_t *ptr = img.getPixelsPtr();

    // Buffers
    uint8_t *original_buffer = (uint8_t *)malloc(buffer_size);
    uint8_t *processed_buffer = (uint8_t *)malloc(buffer_size);

    std::memcpy(original_buffer, ptr, buffer_size);

    // Ventana SFML
    sf::RenderWindow window(sf::VideoMode({(unsigned int)(WIDTH), (unsigned int)(HEIGHT)}), "Examen Final : Image Blur");

    sf::Texture texture(sf::Vector2u(WIDTH, HEIGHT));
    texture.update(original_buffer);
    sf::Sprite sprite(texture);

    sprite.setScale({window.getSize().x * 1.0f / WIDTH, window.getSize().y * 1.0f / HEIGHT});

    const sf::Font font(arial_ttf::data, arial_ttf::data_len);

    sf::Text textOverlay(font, "", 24);
    textOverlay.setFillColor(sf::Color::Yellow);
    textOverlay.setOutlineColor(sf::Color::Black);
    textOverlay.setOutlineThickness(2.0f);
    textOverlay.setPosition({20, 20});
    textOverlay.setStyle(sf::Text::Bold);

    sf::Text textOptions(font, "TECLAS: [B] Aplicar Filtro | [R] Restaurar Original | [ESC] Salir", 20);
    textOptions.setFillColor(sf::Color::White);
    textOptions.setOutlineColor(sf::Color::Black);
    textOptions.setOutlineThickness(2.0f);
    textOptions.setPosition({20, window.getView().getSize().y - 40});

    bool filtrado = false;
    bool cuda = true;
    double tiempoProceso = 0.0;

    // FPS
    int frames = 0;
    int fps = 0;
    sf::Clock clockFrames;

    while (window.isOpen())
    {
        while (const std::optional event = window.pollEvent())
        {
            if (event->is<sf::Event::Closed>())
            {
                window.close();
            }
            else if (event->is<sf::Event::KeyReleased>())
            {
                auto evt = event->getIf<sf::Event::KeyReleased>();

                switch (evt->scancode)
                {
                case sf::Keyboard::Scan::R:
                    texture.update(original_buffer);
                    filtrado = false;
                    tiempoProceso = 0.0;
                    break;

                case sf::Keyboard::Scan::B:
                    if (cuda)
                    {
                        tiempoProceso = blur_kernel(original_buffer, processed_buffer, w, h);
                        cuda = false;
                    }
                    else
                    {
                        tiempoProceso = blur_openmp(original_buffer, processed_buffer, w, h);
                        cuda = true;
                    }
                    texture.update(processed_buffer);
                    filtrado = true;
                    break;

                case sf::Keyboard::Scan::Escape:
                    window.close();
                    break;
                }
            }
        }

        // FPS
        frames++;
        if (clockFrames.getElapsedTime().asSeconds() >= 1.0f)
        {
            fps = frames;
            frames = 0;
            clockFrames.restart();
        }

        // Overlay
        std::string overlay = fmt::format("Implementacion activa: {}\nEstado: {}\nTiempo de procesamiento: {:.2f} ms\nDimensiones: {}x{}\nFPS: {}",
                                          cuda ? "CUDA (Malla 1D)" : "OpenMP",
                                          filtrado ? "Filtro Aplicado" : "Original",
                                          tiempoProceso, w, h, fps);
        textOverlay.setString(overlay);

        window.clear(sf::Color::Black);
        window.draw(sprite);
        window.draw(textOverlay);
        window.draw(textOptions);
        window.display();

        free(original_buffer);
        free(processed_buffer);

        return 0;
    }
}